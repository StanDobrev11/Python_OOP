import unittest

from project.movie_specification.action import Action
from project.movie_specification.fantasy import Fantasy
from project.user import User


class TestUser(unittest.TestCase):

    def setUp(self) -> None:
        self.u = User('test', 22)
        self.movie = Action('Die Hard', 1988, self.u, 18)
        self.movie2 = Action('Free Guy', 2021, self.u, 16)

    def test_name_validator(self):
        with self.assertRaises(ValueError) as ve:
            self.u.username = ''
        self.assertEqual("Invalid username!", str(ve.exception))

    def test_age_validator(self):
        with self.assertRaises(ValueError) as ve:
            self.u.age = 5
        self.assertEqual("Users under the age of 6 are not allowed!", str(ve.exception))

    def test_proper_str(self):
        self.u.movies_owned.append(self.movie)
        self.u.movies_owned.append(self.movie2)
        expected = "Username: test, Age: 22\nLiked movies:\nNo movies liked.\nOwned movies:\nAction - Title:Die Hard, Year:1988, Age restriction:18, Likes:0, Owned by:test\nAction - Title:Free Guy, Year:2021, Age restriction:16, Likes:0, Owned by:test"
        actual = self.u.__str__()
        self.assertEqual(expected, actual)
        expected = f"Username: test, Age: 22\nLiked movies:\nNo movies liked.\nOwned movies:\n{self.movie.details()}\n{self.movie2.details()}"
        actual = self.u.__str__()
        self.assertEqual(expected, actual)