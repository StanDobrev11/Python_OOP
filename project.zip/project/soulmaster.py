from project.darkknight import DarkKnight


class SoulMaster(DarkKnight):
    pass
