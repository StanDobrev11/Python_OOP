import unittest

from project.mammal import Mammal


class TestMammal(unittest.TestCase):

    def test_proper_init(self):
        m = Mammal('Wolf', 'K9', 'woff')
        self.assertEqual('Wolf', m.name)
        self.assertEqual('K9', m.type)
        self.assertEqual('woff', m.sound)
        self.assertEqual("animals", m._Mammal__kingdom)

    def test_make_sound(self):
        m = Mammal('Wolf', 'K9', 'woff')
        result = m.make_sound()
        expected_result = 'Wolf makes woff'
        self.assertEqual(expected_result, result)

    def test_get_kingdom(self):
        m = Mammal('Wolf', 'K9', 'woff')
        self.assertEqual(m._Mammal__kingdom, m.get_kingdom())

    def test_info(self):
        m = Mammal('Wolf', 'K9', 'woff')
        result = m.info()
        expected_result = f"{m.name} is of type {m.type}"
        self.assertEqual(expected_result, result)


if __name__ == '__main__':
    unittest.main()
